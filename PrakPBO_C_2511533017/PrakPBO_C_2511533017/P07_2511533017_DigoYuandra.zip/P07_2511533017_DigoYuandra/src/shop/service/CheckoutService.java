package shop.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import shop.exception.OutOfStockException;
import shop.exception.PaymentFailedException;
import shop.model.Product;
import shop.payment.PaymentMethod;
import shop.payment.RefundablePayment;
import shop.shipping.Shippable;
import shop.shipping.ShippingService;

public class CheckoutService {
    private final Inventory inventory;
    public CheckoutService() { this(new Inventory()); }
    public CheckoutService(Inventory inventory) {
        if (inventory == null) throw new IllegalArgumentException("Inventory is required");
        this.inventory = inventory;
    }
    public long subtotal(List<Product> items) {
        long total = 0;
        for (Product product : items) total += product.getFinalPrice();
        return total;
    }
    public int totalWeight(List<Product> items) {
        int grams = 0;
        for (Product product : items) if (product instanceof Shippable s) grams += s.getWeightGrams();
        return grams;
    }
    public long total(List<Product> items, ShippingService shipping) {
        return subtotal(items) + shipping.calculateCost(totalWeight(items));
    }
    public long checkout(List<Product> items, ShippingService shipping, PaymentMethod payment)
            throws OutOfStockException, PaymentFailedException {
        if (items == null || items.isEmpty()) throw new IllegalStateException("Keranjang kosong.");
        if (shipping == null || payment == null) throw new IllegalArgumentException("Shipping dan payment wajib diisi");

        Map<String, Integer> quantities = new LinkedHashMap<>();
        Map<String, Integer> reserved = new LinkedHashMap<>();
        for (Product p : items) quantities.merge(p.getSku(), 1, Integer::sum);
        try {
            for (Map.Entry<String, Integer> entry : quantities.entrySet()) {
                inventory.reserve(entry.getKey(), entry.getValue());
                reserved.put(entry.getKey(), entry.getValue());
            }
            long amount = total(items, shipping);
            payment.pay(amount);
            return amount;
        } catch (OutOfStockException | PaymentFailedException | RuntimeException e) {
            for (Map.Entry<String, Integer> entry : reserved.entrySet()) {
                inventory.release(entry.getKey(), entry.getValue());
            }
            throw e;
        }
    }
    public boolean refund(RefundablePayment payment, long amount) { return payment.refund(amount); }
}

package shop.exception;

public class InsufficientBalanceException extends PaymentFailedException {
    private static final long serialVersionUID = 1L;
    private final long shortfall;
    public InsufficientBalanceException(long amount, long available) {
        super("Saldo kurang Rp" + (amount - available));
        this.shortfall = amount - available;
    }
    public long getShortfall() { return shortfall; }
}

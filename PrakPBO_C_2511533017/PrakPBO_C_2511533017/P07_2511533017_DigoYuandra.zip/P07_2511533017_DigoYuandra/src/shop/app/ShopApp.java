package shop.app;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import shop.StudentInfo;
import shop.exception.InsufficientBalanceException;
import shop.exception.OutOfStockException;
import shop.exception.PaymentFailedException;
import shop.io.CatalogReader;
import shop.model.Product;
import shop.payment.EWalletPayment;
import shop.payment.PaymentMethod;
import shop.service.CheckoutService;
import shop.service.Inventory;
import shop.shipping.RegularShipping;
import shop.shipping.ShippingService;

public class ShopApp {
    public static String buy(CheckoutService checkout, List<Product> cart,
            ShippingService shipping, PaymentMethod payment) {
        try {
            long paid = checkout.checkout(cart, shipping, payment);
            return "[OK] Pembayaran berhasil Rp" + paid;
        } catch (InsufficientBalanceException e) {
            return "[SALDO] Pembayaran gagal, saldo kurang Rp" + e.getShortfall();
        } catch (PaymentFailedException e) {
            return "[BAYAR] " + e.getMessage();
        } catch (OutOfStockException e) {
            return "[STOK] " + e.getMessage();
        } catch (IllegalStateException e) {
            return "[INVALID] " + e.getMessage();
        }
    }

    public static void main(String[] args) {
        List<Product> catalog;
        try {
            catalog = new CatalogReader().load(Path.of("katalog.csv"));
        } catch (Exception e) {
            System.out.println("Toko tidak bisa dibuka: " + e.getMessage());
            return;
        }
        Inventory inventory = new Inventory();
        for (Product p : catalog) inventory.addStock(p.getSku(), StudentInfo.stockFor(p.getSku()));

        System.out.println("== Toko Online UMKM ==");
        for (int i = 0; i < catalog.size(); i++) System.out.println((i + 1) + ". " + catalog.get(i).getInfo());
        List<Product> cart = new ArrayList<>();
        try (Scanner in = new Scanner(System.in)) {
            while (true) {
                System.out.print("Nomor Produk (0 = selesai): ");
                String text = in.nextLine().trim();
                int choice;
                try { choice = Integer.parseInt(text); }
                catch (NumberFormatException e) { System.out.println("Input harus berupa angka."); continue; }
                if (choice == 0) break;
                if (choice < 1 || choice > catalog.size()) {
                    System.out.println("Nomor produk tidak ada.");
                    continue;
                }
                Product product = catalog.get(choice - 1);
                while (true) {
                    System.out.print("Jumlah: ");
                    String qtyText = in.nextLine().trim();
                    int quantity;
                    try { quantity = Integer.parseInt(qtyText); }
                    catch (NumberFormatException e) { System.out.println("Input harus berupa angka."); continue; }
                    if (quantity <= 0) { System.out.println("Jumlah harus lebih dari 0."); continue; }
                    if (quantity > inventory.available(product.getSku())) {
                        System.out.println("Stok tidak mencukupi.");
                        break;
                    }
                    for (int i = 0; i < quantity; i++) cart.add(product);
                    System.out.println("  + " + quantity + " x " + product.getName());
                    break;
                }
            }
        }
        if (cart.isEmpty()) {
            System.out.println("Keranjang kosong.");
            return;
        }
        CheckoutService checkout = new CheckoutService(inventory);
        ShippingService regular = new RegularShipping();
        EWalletPayment wallet = new EWalletPayment("DompetKu", StudentInfo.walletBalance());
        System.out.println("\nKeranjang: " + cart.size() + " barang, total Reguler Rp" + checkout.total(cart, regular));
        System.out.println(buy(checkout, cart, regular, wallet));
        System.out.println("Sisa saldo: Rp" + wallet.getBalance());
    }
}

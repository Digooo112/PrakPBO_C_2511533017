PRAKTIKUM P07/P10 - EXCEPTION HANDLING
Nama : DIGO YUANDRA
NIM  : 2511533017
Kelas: C

ISI FOLDER
- src/       : seluruh source code Java
- katalog.csv: data katalog (4 baris valid dan 3 baris rusak untuk uji L4)
- .vscode/   : pengaturan proyek dan konfigurasi Run dengan folder kerja proyek

PENTING
1. Ekstrak ZIP terlebih dahulu.
2. Di VS Code pilih File > Open Folder, lalu buka folder P07_Digo_Yuandra_2511533017
   (folder yang langsung berisi katalog.csv dan src).
3. Pastikan JDK yang aktif adalah Java 25 atau lebih baru.
4. Jangan menyalin file CatalogReader.java TODO dari ZIP bahan dosen untuk menimpa
   src/shop/io/CatalogReader.java yang sudah diimplementasikan di proyek ini.
5. Jangan mengubah SelfCheck.java.

CARA PALING AMAN MENJALANKAN SELFCHECK (TERMINAL VS CODE / POWERSHELL)
Pastikan terminal berada di folder utama proyek, yaitu folder yang berisi katalog.csv.
Jalankan:

$root = (Get-Location).Path
Write-Host "Folder kerja: $root"
Test-Path .\katalog.csv
Test-Path .\src\shop\io\CatalogReader.java

Kedua perintah Test-Path harus menghasilkan True.

Kemudian kompilasi semua source code dari folder utama:

if (Test-Path .\bin) { Remove-Item .\bin -Recurse -Force }
New-Item -ItemType Directory -Force .\bin | Out-Null
$files = (Get-ChildItem .\src -Recurse -Filter *.java).FullName
javac -encoding UTF-8 -d .\bin $files
if ($LASTEXITCODE -ne 0) { throw 'Kompilasi gagal. Periksa pesan javac di atas.' }
java -cp .\bin selfcheck.SelfCheck

HASIL YANG DIHARAPKAN PADA JDK 25+
=== HASIL: 24 / 24 pemeriksaan lulus ===

Catatan verifikasi:
Source code berhasil dikompilasi dan L1, L3, L4, L5 lulus saat diuji di lingkungan
pembuatan. Lingkungan pembuatan hanya menyediakan Java 21, sehingga L0.1 memang
menjadi satu-satunya pemeriksaan yang gagal di sini. Pada komputer mahasiswa dengan
Java 25, L0.1 seharusnya lulus. SelfCheck tidak diubah.
